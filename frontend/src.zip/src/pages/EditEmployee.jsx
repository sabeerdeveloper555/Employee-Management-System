import {
  HiOutlinePhone,
  HiOutlineCurrencyDollar,
  HiOutlineCalendar,
  HiOutlineUser,
  HiOutlineMail,
} from "react-icons/hi";
import Header from "../components/layout/Header.jsx";
import Card from "../components/common/Card.jsx";
import Button from "../components/common/Button.jsx";
import Input from "../components/common/Input.jsx";

const departments = ["Engineering", "Design", "Operations", "Marketing", "HR"];
const statuses = ["Active", "Inactive"];

export default function EditEmployee() {
  return (
    <div className="space-y-6">
      <Header
        title="Edit Employee"
        subtitle="Update an employee’s details while keeping the experience consistent."
        actions={
          <Button variant="outline" to="/employees">
            Back to list
          </Button>
        }
      />

      <Card className="border-slate-200/80">
        <form className="grid gap-6 lg:grid-cols-2">
          <div className="space-y-5">
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4">
              <h3 className="text-lg font-semibold text-slate-900">Profile details</h3>
              <p className="mt-1 text-sm text-slate-500">
                Review and update personal information responsibly.
              </p>
            </div>

            <Input label="Full Name" icon={HiOutlineUser} placeholder="Alex Morgan" defaultValue="Alex Morgan" required />
            <Input label="Email" icon={HiOutlineMail} type="email" placeholder="alex@peoplehub.com" defaultValue="alex@peoplehub.com" required />
            <Input label="Phone" icon={HiOutlinePhone} type="tel" placeholder="+1 555 0148" defaultValue="+1 555 0148" required />
          </div>

          <div className="space-y-5">
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4">
              <h3 className="text-lg font-semibold text-slate-900">Role & employment</h3>
              <p className="mt-1 text-sm text-slate-500">
                Adjust role, compensation, and team status as needed.
              </p>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Department <span className="text-rose-500">*</span>
              </label>
              <select className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100" defaultValue="Engineering">
                {departments.map((department) => (
                  <option key={department} value={department}>
                    {department}
                  </option>
                ))}
              </select>
            </div>

            <Input label="Position" placeholder="Senior Product Designer" defaultValue="Senior Product Designer" required />
            <Input label="Salary" icon={HiOutlineCurrencyDollar} placeholder="120000" defaultValue="120000" required />
            <Input label="Joining Date" icon={HiOutlineCalendar} type="date" defaultValue="2024-01-15" required />

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Status <span className="text-rose-500">*</span>
              </label>
              <select className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100" defaultValue="Active">
                {statuses.map((status) => (
                  <option key={status} value={status}>
                    {status}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="lg:col-span-2 flex flex-col gap-3 border-t border-slate-200 pt-4 sm:flex-row sm:justify-end">
            <Button variant="outline" to="/employees">
              Cancel
            </Button>
            <Button variant="primary" type="submit">
              Update Employee
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
