import { Link } from "react-router-dom";
import {
  HiOutlineSearch,
  HiOutlinePencil,
  HiOutlineTrash,
} from "react-icons/hi";
import { HiOutlineUserPlus } from "react-icons/hi2";
import Header from "../components/layout/Header.jsx";
import Card from "../components/common/Card.jsx";
import Button from "../components/common/Button.jsx";
import Badge from "../components/common/Badge.jsx";
import Input from "../components/common/Input.jsx";

const employees = [
  {
    id: 1,
    name: "Ava Patel",
    email: "ava.patel@peoplehub.com",
    phone: "+1 555 0148",
    department: "Design",
    position: "Product Designer",
    salary: "$96k",
    joinDate: "2024-06-12",
    status: "Active",
  },
  {
    id: 2,
    name: "Marcus Lee",
    email: "marcus.lee@peoplehub.com",
    phone: "+1 555 0150",
    department: "Engineering",
    position: "Frontend Engineer",
    salary: "$128k",
    joinDate: "2024-05-02",
    status: "Active",
  },
  {
    id: 3,
    name: "Nadia Chen",
    email: "nadia.chen@peoplehub.com",
    phone: "+1 555 0199",
    department: "Operations",
    position: "Operations Lead",
    salary: "$112k",
    joinDate: "2023-09-18",
    status: "Inactive",
  },
  {
    id: 4,
    name: "Daniel Brooks",
    email: "daniel.brooks@peoplehub.com",
    phone: "+1 555 0173",
    department: "Marketing",
    position: "Brand Strategist",
    salary: "$88k",
    joinDate: "2023-12-31",
    status: "Active",
  },
];

export default function Employees() {
  return (
    <div className="space-y-6">
      <Header
        title="Employees"
        subtitle="Manage your team members, roles, and current engagement status."
        actions={
          <Button to="/employees/add" icon={HiOutlineUserPlus} variant="primary">
            Add Employee
          </Button>
        }
      />

      <Card padded={false} className="overflow-hidden">
        <div className="border-b border-slate-200 bg-slate-50/70 px-4 py-4 sm:px-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div className="flex-1">
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Search employees
              </label>
              <Input
                icon={HiOutlineSearch}
                placeholder="Search by name or email"
                className="max-w-xl"
              />
            </div>

            <div className="flex flex-col gap-3 sm:flex-row">
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">
                  Department
                </label>
                <select className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100">
                  <option>All Departments</option>
                  <option>Engineering</option>
                  <option>Design</option>
                  <option>Operations</option>
                  <option>Marketing</option>
                </select>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">
                  Status
                </label>
                <select className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100">
                  <option>All Status</option>
                  <option>Active</option>
                  <option>Inactive</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-white text-slate-500">
              <tr>
                <th className="px-4 py-3 font-medium sm:px-6">Employee</th>
                <th className="px-4 py-3 font-medium sm:px-6">Phone</th>
                <th className="px-4 py-3 font-medium sm:px-6">Department</th>
                <th className="px-4 py-3 font-medium sm:px-6">Position</th>
                <th className="px-4 py-3 font-medium sm:px-6">Salary</th>
                <th className="px-4 py-3 font-medium sm:px-6">Status</th>
                <th className="px-4 py-3 font-medium sm:px-6">Actions</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((employee) => (
                <tr key={employee.id} className="border-t border-slate-200/80">
                  <td className="px-4 py-4 sm:px-6">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-100 font-semibold text-indigo-700">
                        {employee.name
                          .split(" ")
                          .map((part) => part[0])
                          .join("")}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-800">{employee.name}</p>
                        <p className="text-sm text-slate-500">{employee.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-slate-600 sm:px-6">{employee.phone}</td>
                  <td className="px-4 py-4 text-slate-600 sm:px-6">{employee.department}</td>
                  <td className="px-4 py-4 text-slate-600 sm:px-6">{employee.position}</td>
                  <td className="px-4 py-4 text-slate-600 sm:px-6">{employee.salary}</td>
                  <td className="px-4 py-4 sm:px-6">
                    <Badge variant={employee.status === "Active" ? "success" : "warning"}>
                      {employee.status}
                    </Badge>
                  </td>
                  <td className="px-4 py-4 sm:px-6">
                    <div className="flex items-center gap-2">
                      <Link
                        to={`/employees/edit/${employee.id}`}
                        className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-indigo-200 hover:text-indigo-600"
                      >
                        <HiOutlinePencil className="h-4 w-4" />
                      </Link>
                      <button className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-rose-200 hover:text-rose-600">
                        <HiOutlineTrash className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
